let nombre = localStorage.getItem("nombre")
let auth = localStorage.getItem("auth")

document.getElementById("name").innerText = nombre

if (auth != "true") {
  location.href = "./../html/index.html"
}

/* petición para mostrar productos */
let template_products = ""
fetch("http://localhost:3000/products")
  .then(result => result.json())
  .then(data => {
    let tbody = document.getElementById("tbody_products")
    data.forEach(Element => {
      template_products += `
        <tr>
            <td>${Element.id}</td>
            <td>${Element.name}</td>
            <td>${Element.description}</td>
            <td><img src="${Element.img}" alt="imagen-producto" style="height: 2rem"></img></td>
            <td>${Element.price}</td>
            <td>
                <a class="btn btn-danger btn-sm" onclick="deleteProduct('${Element.id}')">Eliminar</a>
            </td>
        </tr>
        `
      tbody.innerHTML = template_products
    })
  })

/* petición para mostrar usuarios */
let template_users = ""
fetch("http://localhost:3000/users")
  .then(result => result.json())
  .then(data => {
    let tbody = document.getElementById("tbody_users")
    data.forEach(Element => {
      template_users += `
        <tr>
          <td>${Element.id}</td>
          <td>${Element.name}</td>
          <td>${Element.lastname}</td>
          <td>${Element.email}</td>
          <td>${Element.phone}</td>
          <td>
            <a class="btn btn-danger btn-sm" onclick="deleteUser('${Element.id}')">Eliminar</a>
          </td>
        </tr>
        `
        tbody.innerHTML = template_users
    })
  })

/* funcion para eliminar productos */
function deleteProduct(id) {
  fetch("http://localhost:3000/products/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })
}

/* función para eliminar usuarios */
function deleteUser(id){
  fetch("http://localhost:3000/users" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(result => result.json())
  .then(data => {
    location.href = ""
  })

}