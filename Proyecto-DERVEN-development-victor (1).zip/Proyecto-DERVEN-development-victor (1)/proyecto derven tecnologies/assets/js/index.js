/* petición para mostrar los productos  */

template_cards = ""
fetch("http://localhost:3000/products")
  .then(result => result.json())
  .then(data => {
    let cards = document.getElementById("cards")
    data.forEach(element => {
      template_cards += `
      <div class=" col-3 g-2 card shadow" style:>
        <img src="${element.img}" class="card-img-top" alt="imagen-procesador">
          <div class="card-body">
          <h5 class="card-title">${element.name}</h5>
          <p class="card-text">${element.description}</p>
          <a href="#" class="btn btn-primary w-100">Comprar</a>
        </div>
      </div>
      `
      cards.innerHTML = template_cards
    })

  })

/* petición para mostrar las categorias */

template_categories = ""
fetch("http://localhost:3000/categories")
  .then(result => result.json())
  .then(data => {
    let categories = document.getElementById("tbody_category")
    data.forEach(item => {
      template_categories += `
      <tr>
        <td>${item.name}</td>
      </tr>
      `
      categories.innerHTML = template_categories
    })
  })

/* petición para registrar nuevos usuarios */

function createUser() {
  let name = document.getElementById("create_name")
  let email = document.getElementById("create_email")
  let phone = document.getElementById("create_phone")
  let password = document.getElementById("create_password")

  let data_user = {
    name: name.value,
    email: email.value,
    phone: phone.value,
    password: password.value
  }

  fetch("http://localhost:3000/users", {
    method: "POST",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = "./index.html"
      
    })
}

/* autenticar / usuario registrado */

function verifyUser() {
  let phone = document.getElementById("get_phone")
  let password = document.getElementById("get_password")

  fetch("http://localhost:3000/users")
    .then(result => result.json())
    .then(data => {

      let resultado = data.filter(function (element) {
        return element.phone == phone.value
      })

      if(resultado.length > 0){
        if(resultado[0].password == password.value){
          localStorage.setItem("autenticado", "si")
          location.href = "./../admin/users.html"
        }else{
          console.log("correo y contraseña incorrecto")
        }
      }else{
        console.log("No hay coincidencias")
      }
    })
}

/* salir para usuarios */

function signOff(){
  let cerrar = document.getElementById("cerrar_sesion")
  localStorage.getItem("autenticado", "")
  location.href = "./../html/index.html"
}
