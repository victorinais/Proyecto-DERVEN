/* petición para mostrar los productos  */

template_cards = ""
fetch("http://localhost:3000/products")
  .then(result => result.json())
  .then(data => {
    let cards = document.getElementById("cards")
    data.forEach(element => {
      template_cards += `
      <div class=" col-3 mb-2 card shadow">
        <img src="${element.img}" class="card-img-top" alt="imagen-procesador">
          <div class="card-body">
          <h5 class="card-title">${element.name}</h5>
          <p class="card-text">${element.description}</p>
          <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
      </div>
      `
      cards.innerHTML = template_cards
    })

  })

/* petición para mostrar las categorias */

template_categories = ""
fetch("http://localhost:3000/categories")
  .then(result => result.json())
  .then(data => {
    let categories = document.getElementById("tbody_category")
    data.forEach(item => {
      template_categories += `
      <tr>
        <td>${item.name}</td>
      </tr>
      `
      categories.innerHTML = template_categories
    })
  })

/*   registrar nuevos usuarios */

function createUser() {
  let name = document.getElementById("create_name")
  let email = document.getElementById("create_email")
  let phone = document.getElementById("create_phone")
  let password = document.getElementById("create_password")

  let data_user = {
    name: name.value,
    email: email.value,
    phone: phone.value,
    password: password.value
  }

  fetch("http://localhost:3000/users", {
    method: "POST",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })
}

/* verificar / usuario registrado */

function verifyUser() {
  let phone_i = document.getElementById("get_phone").value
  let password_i = document.getElementById("get_password").value

  fetch("http://localhost:3000/users/" + toString.phone_i)
    .then(result => result.json())
    .then(data => {
      if (data) {
        if (toString.password_i === data.password) {
          alert("Usuario verificado correctamente")
        } else {
          alert("Numero de telefono o contraseña incorrectos")
        } 
      } else {
        alert("Error al verificar el usuario")
      }
      location.href = "./../../admin/users.html"
    })
}

