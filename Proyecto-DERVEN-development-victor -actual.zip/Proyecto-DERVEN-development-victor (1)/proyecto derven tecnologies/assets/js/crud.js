let nombre = localStorage.getItem("nombre")
let auth = localStorage.getItem("auth")

document.getElementById("name").innerText = nombre

if (auth != "true") {
  location.href = "./../html/index.html"
}

/* petición para mostrar productos */
let template_products = ""
fetch("http://localhost:3000/products")
  .then(result => result.json())
  .then(data => {
    let tbody = document.getElementById("tbody_products")
    data.forEach(element => {
      template_products += `
        <tr>
            <td>${element.id}</td>
            <td>${element.name}</td>
            <td>${element.description}</td>
            <td><img src="${element.img}" alt="imagen-producto" style="height: 2rem"></img></td>
            <td>${element.price}</td>
            <td>
                <a class="btn btn-danger btn-sm" onclick="deleteProduct('${element.id}')">Eliminar</a>
            </td>
        </tr>
        `
      tbody.innerHTML = template_products;
    })
  })

/* petición para mostrar usuarios */
let template_users = ""
fetch("http://localhost:3000/users")
  .then(result => result.json())
  .then(data => {
    let tbody = document.getElementById("tbody_users")
    data.forEach(item => {
      template_users += `
        <tr>
          <td>${item.id}</td>
          <td>${item.name}</td>
          <td>${item.lastname}</td>
          <td>${item.email}</td>
          <td>${item.phone}</td>
          <td>
            <a class="btn btn-danger btn-sm" onclick="deleteUser('${item.id}')">Eliminar</a>
          </td>
        </tr>
        `
      tbody.innerHTML = template_users;
    })
  })

/* funcion para eliminar productos */
function deleteProduct(id) {
  fetch("http://localhost:3000/products/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })
}

/* función para eliminar usuarios */
function deleteUser(id) {
  fetch("http://localhost:3000/users/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })

}

/* función para crear producto */
function createProduct() {
  let name = document.getElementById("name_create")
  let description = document.getElementById("descriptión_create")
  let image = document.getElementById("image_create")
  let price = document.getElementById("precio_create")

  data_product = {
    name: name.value,
    description: description.value,
    image: image.value,
    price: price.value
  }

  fetch("http://localhost:3000/products", {
    method: "POST",
    body: JSON.stringify(data_product),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })
}

/* función para crear usuario */
function createUser() {
  let name = document.getElementById("create_name")
  let lastname = document.getElementById("create_lastname")
  let email = document.getElementById("create_email")
  let phone = document.getElementById("create_phone")

  data_user = {
    name: name.value,
    lastname: lastname.value,
    email: email.value,
    phone: phone.value
  }

  fetch("http://localhost:3000/users", {
    method: "POST",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })
}

/* funcion para cerrar sesión */
let btn = document.getElementById("close")
btn.addEventListener("click", close)
function close() {
    localStorage.setItem("nombre", "")
    localStorage.setItem("auth", "")
    location.href = "../html/index.html"
  }
