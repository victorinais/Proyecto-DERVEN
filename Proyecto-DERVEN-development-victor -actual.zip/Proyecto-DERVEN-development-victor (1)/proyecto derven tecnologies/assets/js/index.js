/* nav dibujado con js */
let nav = document.getElementById("nav")
let template_nav = `
  <nav class="navbar navbar-expand-md bg-body-tertiary">
      <div class="container-fluid">
        <button class="navbar-toggler order-2 order-md-1" type="button"
          data-bs-toggle="collapse"
          data-bs-target=".navbar-collapse" aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse order-3 order-md-2"
          id="navbar-left">
          <ul class="navbar-nav me-auto">
            <li class="nav-item">
              <a class="nav-link" href="./../admin/login_admin.html"><i class="bi bi-house"></i></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Contacto</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Sobre Nosotros</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Categorías</a>
            </li>
          </ul>
        </div>
        <a class="navbar-brand order-1 order-md-3" href="#"><img
            src="./../assets/images/logo.png" alt="logo-D-T" /></a>
        <div class="collapse navbar-collapse order-4 order-md-4"
          id="navbar-right">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <button type="button" class="btn btn-outline-primary mx-2"><a
                  class="nav-link" href="./login.html">Crea tu cuenta</a></button>
            </li>
            <li class="nav-item">
              <button type="button" class="btn btn-outline-primary mx-2"><a
                  class="nav-link" href="./login.html">Ingresar</a></button>
            </li>
            <li class="nav-item">
              <button type="button" class="btn btn-outline-warning mx-2"><a
                  class="nav-link" href="#">Mis compras</a></button>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><i class="bi bi-cart"></i></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
`
nav.innerHTML = template_nav

if (localStorage.getItem("autenticado") == "si") {
  let template_nav = `
  <nav class="navbar navbar-expand-md bg-body-tertiary">
      <div class="container-fluid">
        <button class="navbar-toggler order-2 order-md-1" type="button"
          data-bs-toggle="collapse"
          data-bs-target=".navbar-collapse" aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse order-3 order-md-2"
          id="navbar-left">
          <ul class="navbar-nav me-auto">
            <li class="nav-item">
              <a class="nav-link" href="./../admin/login_admin.html"><i class="bi bi-house"></i></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Contacto</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Sobre Nosotros</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Categorías</a>
            </li>
          </ul>
        </div>
        <a class="navbar-brand order-1 order-md-3" href="#"><img
            src="./../assets/images/logo.png" alt="logo-D-T" /></a>
        <div class="collapse navbar-collapse order-4 order-md-4"
          id="navbar-right">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              
            </li>
            <li class="nav-item">
              <button type="button" class="btn btn-outline-danger mx-2" id="cerrar" onclick="signOff()"><a
                  class="nav-link">Cerrar</a></button>
            </li>
            <li class="nav-item">
              <button type="button" class="btn btn-outline-warning mx-2"><a
                  class="nav-link" href="#">Mis compras</a></button>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><i class="bi bi-cart"></i></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  `
  nav.innerHTML = template_nav
}


/* petición para mostrar los productos  */
template_cards = ""
fetch("http://localhost:3000/products")
  .then(result => result.json())
  .then(data => {
    let cards = document.getElementById("cards")
    data.forEach(element => {
      template_cards += `
      <div class=" col-3 g-2 card shadow" style:>
        <img src="${element.img}" class="card-img-top" alt="imagen-procesador">
          <div class="card-body">
          <h5 class="card-title">${element.name}</h5>
          <p class="card-text">${element.description}</p>
          <h5>${element.price}</h5>
          <a href="#" class="btn btn-primary w-100">Comprar</a>
        </div>
      </div>
      `
      cards.innerHTML = template_cards
    })

  })

/* petición para mostrar las categorias */

template_categories = ""
fetch("http://localhost:3000/categories")
  .then(result => result.json())
  .then(data => {
    let categories = document.getElementById("tbody_category")
    data.forEach(item => {
      template_categories += `
      <tr>
        <td>${item.name}</td>
      </tr>
      `
      categories.innerHTML = template_categories
    })
  })

/* petición para registrar nuevos usuarios */

function createUser() {
  let name = document.getElementById("create_name")
  let lastname = document.getElementById("create_lastname")
  let email = document.getElementById("create_email")
  let phone = document.getElementById("create_phone")
  let password = document.getElementById("create_password")

  let data_user = {
    name: name.value,
    lastname: lastname.value,
    email: email.value,
    phone: phone.value,
    password: password.value
  }

  fetch("http://localhost:3000/users", {
    method: "POST",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = "./index.html"
      
    })
}

/* autenticar / usuario registrado */

function verifyUser() {
  let phone = document.getElementById("get_phone")
  let password = document.getElementById("get_password")

  fetch("http://localhost:3000/users")
    .then(result => result.json())
    .then(data => {

      let resultado = data.filter(function (element) {
        return element.phone == phone.value
      })

      if(resultado.length > 0){
        if(resultado[0].password == password.value){
          localStorage.setItem("autenticado", "si")
          location.href = "../html/index.html"
        }else{
          console.log("correo y contraseña incorrecto")
        }
      }else{
        console.log("No hay coincidencias")
      }
    })
}

/* salir para usuarios */
let btn = document.getElementById("cerrar")
btn.addEventListener("click", signOff)
function signOff(){
  localStorage.setItem("autenticado", "")
  location.href = "./../html/index.html"
}


