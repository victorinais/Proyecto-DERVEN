function verifySuperUser() {
  let name = document.getElementById("name_login");
  let email = document.getElementById("email_login");
  let password = document.getElementById("password_login");

  fetch("http://localhost:3000/super_users")
    .then((result) => result.json())
    .then((data) => {
      let resultado = data.filter(function (element) {
        return element.email == email.value;
      });
      if (resultado.length > 0) {
        if (resultado[0].password == password.value) {
          console.log("Correo y contraseñas correctas");
          localStorage.setItem("auth", "true");
          localStorage.setItem("nombre", name.value);
          location.href = "./../admin/crud_products.html";
        } else {
          console.error("correo o contraseña incorrectos");
        }
      } else {
        console.log("No hay coincidencias");
      }
    });
}
