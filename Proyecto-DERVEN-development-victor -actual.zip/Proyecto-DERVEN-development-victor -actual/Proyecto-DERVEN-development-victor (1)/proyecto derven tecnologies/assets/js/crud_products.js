let nombre = localStorage.getItem("nombre")
let auth = localStorage.getItem("auth")

document.getElementById("name").innerText = nombre

if (auth != "true") {
  location.href = "./../html/index.html"
}

/* petición para mostrar productos */
let template_products = ""
fetch("http://localhost:3000/products")
  .then(result => result.json())
  .then(data => {
    let tbody = document.getElementById("tbody_products")
    data.forEach(element => {
      template_products += `
        <tr>
            <td>${element.id}</td>
            <td>${element.name}</td>
            <td>${element.description}</td>
            <td><img src="${element.img}" alt="imagen-producto" style="height: 2rem"></img></td>
            <td>${element.price}</td>
            <td>
                <a class="btn btn-danger btn-sm" onclick="deleteProduct('${element.id}')">Eliminar</a>
            </td>
        </tr>
        `
      tbody.innerHTML = template_products;
    })
  })



/* funcion para eliminar productos */
function deleteProduct(id) {
  fetch("http://localhost:3000/products/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })
}


/* función para crear producto */
function createProduct() {
  let name = document.getElementById("name_create")
  let description = document.getElementById("descriptión_create")
  let image = document.getElementById("image_create")
  let price = document.getElementById("precio_create")
  let id_category = document.getElementById("select_create")

  data_product = {
    name: name.value,
    description: description.value,
    img: image.value,
    price: price.value,
    id_category: id_category.value
  }

  fetch("http://localhost:3000/products", {
    method: "POST",
    body: JSON.stringify(data_product),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })
}



/* funcion para cerrar sesión */
if (localStorage.getItem("auth") == "true") {
  let btn = document.getElementById("close")
  btn.addEventListener("click", close)
  function close() {
    localStorage.setItem("nombre", "")
    localStorage.setItem("auth", "")
    location.href = "../html/index.html"
  }
}

