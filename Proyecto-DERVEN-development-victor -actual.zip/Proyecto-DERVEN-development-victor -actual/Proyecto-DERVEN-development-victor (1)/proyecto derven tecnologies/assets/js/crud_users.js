let nombre = localStorage.getItem("nombre")
let auth = localStorage.getItem("auth")

document.getElementById("name").innerText = nombre

if (auth != "true") {
  location.href = "./../html/index.html"
}

/* petición para mostrar usuarios */
let template_users = ""
fetch("http://localhost:3000/users")
  .then(result => result.json())
  .then(data => {
    let tbody = document.getElementById("tbody_users")
    data.forEach(item => {
      template_users += `
        <tr>
          <td>${item.id}</td>
          <td>${item.name}</td>
          <td>${item.lastname}</td>
          <td>${item.email}</td>
          <td>${item.phone}</td>
          <td>
            <a class="btn btn-danger btn-sm" onclick="deleteUser('${item.id}')">Eliminar</a>
          </td>
        </tr>
        `
      tbody.innerHTML = template_users;
    })
  })

  /* función para eliminar usuarios */
function deleteUser(id) {
    fetch("http://localhost:3000/users/" + id, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json"
      }
    })
      .then(result => result.json())
      .then(data => {
        location.href = ""
      })
  
  }
  

  /* función para crear usuario */
function createUser() {
    let name = document.getElementById("create_name")
    let lastname = document.getElementById("create_lastname")
    let email = document.getElementById("create_email")
    let phone = document.getElementById("create_phone")
  
    data_user = {
      name: name.value,
      lastname: lastname.value,
      email: email.value,
      phone: phone.value
    }
  
    fetch("http://localhost:3000/users", {
      method: "POST",
      body: JSON.stringify(data_user),
      headers: {
        "Content-Type": "application/json"
      }
    })
      .then(result => result.json())
      .then(data => {
        location.href = ""
      })
  }

  /* funcion para cerrar sesión */
if (localStorage.getItem("auth") == "true") {
    let btn = document.getElementById("close")
    btn.addEventListener("click", close)
    function close() {
      localStorage.setItem("nombre", "")
      localStorage.setItem("auth", "")
      location.href = "../html/index.html"
    }
  }