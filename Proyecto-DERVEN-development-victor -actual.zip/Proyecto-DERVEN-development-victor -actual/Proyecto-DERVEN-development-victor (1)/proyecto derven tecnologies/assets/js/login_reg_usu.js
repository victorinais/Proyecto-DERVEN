/* petición para registrar nuevos usuarios */

function createUser() {
    let name = document.getElementById("create_name")
    let lastname = document.getElementById("create_lastname")
    let email = document.getElementById("create_email")
    let phone = document.getElementById("create_phone")
    let password = document.getElementById("create_password")
  
    let data_user = {
      name: name.value,
      lastname: lastname.value,
      email: email.value,
      phone: phone.value,
      password: password.value
    }
  
    fetch("http://localhost:3000/users", {
      method: "POST",
      body: JSON.stringify(data_user),
      headers: {
        "Content-Type": "application/json"
      }
    })
      .then(result => result.json())
      .then(data => {
        localStorage.setItem("autenticado", "si")
        localStorage.setItem("nombre", name.value)
        location.href = "./index.html"
  
      })
  }
  
  /* autenticar / usuario registrado */
  
  function verifyUser() {
    let name = document.getElementById("get_name")
    let phone = document.getElementById("get_phone")
    let password = document.getElementById("get_password")
  
    fetch("http://localhost:3000/users")
      .then(result => result.json())
      .then(data => {

        let resultado = data.filter(function (element) {
           if(element.phone == phone.value){
            return element
           } 
            
        })

        if (resultado.length > 0) {
          if (resultado[0].password == password.value) {
            localStorage.setItem("autenticado", "si")
            localStorage.setItem("nombre", resultado[0].name)
            location.href = "../html/index.html"
          } else {
            console.log("correo y contraseña incorrecto")
          }
        } else {
          console.log("No hay coincidencias")
        }
      })
  }
  