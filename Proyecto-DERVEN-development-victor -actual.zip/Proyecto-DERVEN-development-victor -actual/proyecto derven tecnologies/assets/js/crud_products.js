/* se obtienen los datos del localStorage para insertar nombre y mantener sesión abierta */
let nombre = localStorage.getItem("nombre")
let auth = localStorage.getItem("auth")

document.getElementById("name").innerText = nombre

if (auth != "true") {
  location.href = "./../html/index.html"
}

/* petición para mostrar productos */
let template_products = ""
fetch("http://localhost:3000/products")
  .then(result => result.json())
  .then(data => {
    let tbody = document.getElementById("tbody_products")
    data.forEach(element => {
      template_products += `
        <tr>
            <td>${element.id}</td>
            <td>${element.name}</td>
            <td>${element.description}</td>
            <td><img src="${element.image}" alt="imagen-producto" style="height: 2rem"></img></td>
            <td>${element.price}</td>
            <td>
              <a class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modal_edit" onclick="fill('${element.id}')">Editar</a>
              <a class="btn btn-danger btn-sm" onclick="deleteProduct('${element.id}')">Eliminar</a>
            </td>
        </tr>
        `
      tbody.innerHTML = template_products;
    })
  })

/* funcion para eliminar productos */
function deleteProduct(id) {
  fetch("http://localhost:3000/products/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })
}

/* función para crear producto */
function createProduct() {
  let name = document.getElementById("name_create")
  let description = document.getElementById("descriptión_create")
  let image = document.getElementById("image_create")
  let price = document.getElementById("precio_create")
  let id_category = document.getElementById("select_create")
  let alert = document.getElementsByClassName(".alert-success")

  data_product = {
    name: name.value,
    description: description.value,
    image: image.value,
    price: price.value,
    id_category: id_category.value
  }

  fetch("http://localhost:3000/products", {
    method: "POST",
    body: JSON.stringify(data_product),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })
}

/* funcion para cerrar sesión */
if (localStorage.getItem("auth") == "true") {
  let btn = document.getElementById("close")
  btn.addEventListener("click", close)
  function close() {
    localStorage.setItem("nombre", "")
    localStorage.setItem("auth", "")
    location.href = "../html/index.html"
  }
}

/* función para rellenar modal */
function fill(id){
  fetch("http://localhost:3000/products/" + id)
  .then(result => result.json())
  .then(data => {
    document.getElementById("name_edit").value = data.name
    document.getElementById("description_edit").value = data.description
    document.getElementById("image_edit").value = data.image
    document.getElementById("price_edit").value = data.price
    document.getElementById("select_edit").value = data.id_category
    document.getElementById("id_edit").value = data.id
  })
}

/* función para actualizar producto */
function update(){
  let name = document.getElementById("name_edit")
  let description = document.getElementById("description_edit")
  let image = document.getElementById("image_edit")
  let price = document.getElementById("price_edit")
  let id_category = document.getElementById("select_edit")
  let id = document.getElementById("id_edit")

  data_product = {
    name: name.value,
    description: description.value,
    image: image.value,
    price: price.value,
    id_category: id_category.value
  }

  fetch("http://localhost:3000/products/" + id.value, {
    method: "PUT",
    body: JSON.stringify(data_product),
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(result => result.json())
  .then(data => {
    location.href = ""
  })
}

/* función para buscar producto */
fetch("http://localhost:3000/products")
  .then(result => result.json())
  .then(data => {
    document.getElementById("search").addEventListener("keyup", () => {
      template_products = ""
      let valor = document.getElementById("search").value.toLowerCase();
      let results = data.filter(item => item.name.toLowerCase().includes(valor));
      let tbody = document.getElementById("tbody_products")
      tbody.innerHTML = ""
      for (let element of results) {
        template_products += `
        <tr>
            <td>${element.id}</td>
            <td>${element.name}</td>
            <td>${element.description}</td>
            <td><img src="${element.image}" alt="imagen-producto" style="height: 2rem"></img></td>
            <td>${element.price}</td>
            <td>
              <a class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modal_edit" onclick="fill('${element.id}')">Editar</a>
              <a class="btn btn-danger btn-sm" onclick="deleteProduct('${element.id}')">Eliminar</a>
            </td>
        </tr>
        `
      tbody.innerHTML = template_products;
      }
    })
  })