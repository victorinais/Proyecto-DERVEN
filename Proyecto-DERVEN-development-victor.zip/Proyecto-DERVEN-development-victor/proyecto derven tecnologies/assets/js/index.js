template_cards = ""
fetch("http://localhost:3000/products")
  .then(result => result.json())
  .then(data => {
    let cards = document.getElementById("cards")
    data.forEach(element => {
      template_cards += `
      <div class="card shadow" style="width: 18rem;>
        <img src="${element.img}" class="card-img-top" alt="imagen-procesador">
          <div class="card-body">
          <h5 class="card-title">${element.name}</h5>
          <p class="card-text">${element.description}</p>
          <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
      </div>
      `
      cards.innerHTML = template_cards
    })

  })