/* se obtienen los datos del localStorage para insertar nombre y mantener sesión abierta */
let nombre = localStorage.getItem("nombre");
let autenticacion = localStorage.getItem("autenticado");

document.getElementById("nombre").innerText = nombre;

/* guardian para no mantener sesion abierta */
if (autenticacion != "si") {
  location.href = "./../index.html";
}

/* petición para mostrar marcas */
template_create_brands = "";
fetch("http://localhost:3000/brands")
  .then((r) => r.json())
  .then((d) => {
    let tbody = document.getElementById("tbody");
    d.forEach((item) => {
      template_create_brands += `
      <tr>
        <td>${item.id}</td>
        <td><img width="100px" src="${item.logo}"alt></td>
        <td>${item.name}</td>
        <td>${item.local}</td>
        <td>${item.floor}</td>
        <td>${item.schedule}</td>
        <td><a href="${item.website}" target="_blank">Sitio web</a></td>
        <td>
          <button class="btn btn-sm btn-info" type="button" class="btn btn-secondary"
          data-bs-toggle="modal" data-bs-target="#detail_brand" onclick="detailBrand('${item.id}')">Detalles</button>
          <button class="btn btn-sm btn-warning" type="button" class="btn btn-secondary"
          data-bs-toggle="modal" data-bs-target="#edit_brand" onclick="fill('${item.id}')">Editar</button>
          <button class="btn btn-sm btn-danger" onclick="deleteBrand('${item.id}')">Eliminar</button>
        </td>
      </tr>
      `;
      tbody.innerHTML = template_create_brands;
    });
  });

/* funcion para crear marcas */
function createBrand() {
  let logo = document.getElementById("logo_create");
  let name = document.getElementById("name_create");
  let local = document.getElementById("local_create");
  let floor = document.getElementById("piso_create");
  let schedule = document.getElementById("horarios_create");
  let website = document.getElementById("website_create");
  let description = document.getElementById("description_create");

  let data_brand = {
    logo: logo.value,
    name: name.value,
    local: local.value,
    floor: floor.value,
    schedule: schedule.value,
    website: website.value,
    description: description.value,
  };

  fetch("http://localhost:3000/brands", {
    method: "POST",
    body: JSON.stringify(data_brand),
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((r) => r.json())
    .then((d) => {
      location.href = "";
    });
}

/* funcion para eliminar brands */
function deleteBrand(id) {
  fetch("http://localhost:3000/brands/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((r) => r.json())
    .then((d) => {
      location.href = "";
    });
}

/* funcion para rellenar modal */
function fill(id) {
  fetch("http://localhost:3000/brands/" + id)
    .then((r) => r.json())
    .then((d) => {
      document.getElementById("logo_edit").value = d.logo;
      document.getElementById("name_edit").value = d.name;
      document.getElementById("local_edit").value = d.local;
      document.getElementById("piso_edit").value = d.floor;
      document.getElementById("horarios_edit").value = d.schedule;
      document.getElementById("website_edit").value = d.website;
      document.getElementById("description_edit").value = d.description;
      document.getElementById("id_edit").value = d.id;
    });
}

/* funcion para editar brand*/
function update() {
  let logo = document.getElementById("logo_edit");
  let name = document.getElementById("name_edit");
  let local = document.getElementById("local_edit");
  let floor = document.getElementById("piso_edit");
  let schedule = document.getElementById("horarios_edit");
  let website = document.getElementById("website_edit");
  let description = document.getElementById("description_edit");
  let id = document.getElementById("id_edit");

  let data_brand = {
    logo: logo.value,
    name: name.value,
    local: local.value,
    floor: floor.value,
    schedule: schedule.value,
    website: website.value,
    description: description.value,
  };

  fetch("http://localhost:3000/brands/" + id.value, {
    method: "PUT",
    body: JSON.stringify(data_brand),
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((r) => r.json())
    .then((d) => {
      location.href = "";
    });
}

/* funcion para mostrar detalles de las brands */
let template_detail_brand = "";
function detailBrand(id) {
  fetch("http://localhost:3000/brands/" + id)
    .then((r) => r.json())
    .then((d) => {
      let tbody = document.getElementById("tbody_detail");
      template_detail_brand = `
      <tr>
        <th>Id:</th>
        <td>${d.id}</td>
      </tr>
      <tr>
        <th>Nombre:</th>
        <td>${d.name}</td>
      </tr>
      <tr>
        <th>Local:</th>
        <td>${d.local}</td>
      </tr>
      <tr>
        <th>Piso:</th>
        <td>${d.floor}</td>
      </tr>
      <tr>
        <th>Horarios:</th>
        <td>${d.schedule}</td>
      </tr>
      <tr>
        <th>Web Site:</th>
        <td>${d.website}</td>
      </tr>
      <tr>
        <th>Descripción:</th>
        <td>${d.description}</td>
      </tr>
      `;
      tbody.innerHTML = template_detail_brand;
    });
}

/* funcion para cerrar sesión */
if (localStorage.getItem("autenticado") == "si") {
  let btn = document.getElementById("close");
  btn.addEventListener("click", close);
  function close() {
    localStorage.setItem("nombre", "");
    localStorage.setItem("autenticado", "");
    location.href = "./../index.html";
  }
}

/* función para buscar por nombre */
function searchName() {
  let valor = document.getElementById("search_name").value.toLowerCase()
  fetch("http://localhost:3000/brands")
    .then((r) => r.json())
    .then((d) => {
      let template_brands = "";
      let tbody = document.getElementById("tbody");
      result = d.filter((item) => item.name.toLowerCase().includes(valor));

      for (let item of result) {
        template_brands += `
        <tr>
          <td>${item.id}</td>
          <td><img width="100px" src="${item.logo}"alt></td>
          <td>${item.name}</td>
          <td>${item.local}</td>
          <td>${item.floor}</td>
          <td>${item.schedule}</td>
          <td><a href="${item.website}" target="_blank">Sitio web</a></td>
          <td>
            <button class="btn btn-sm btn-info" type="button" class="btn btn-secondary"
            data-bs-toggle="modal" data-bs-target="#detail_brand" onclick="detailBrand('${item.id}')">Detalles</button>
            <button class="btn btn-sm btn-warning" type="button" class="btn btn-secondary"
            data-bs-toggle="modal" data-bs-target="#edit_brand" onclick="fill('${item.id}')">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="deleteBrand('${item.id}')">Eliminar</button>
          </td>
        </tr>
        `;
        tbody.innerHTML = template_brands;
      }
    });
}

/* función para buscar por local */
function searchLocal() {
  let valor = document.getElementById("search_local").value;
  fetch("http://localhost:3000/brands")
    .then((r) => r.json())
    .then((d) => {
      let template_brands = "";
      let tbody = document.getElementById("tbody");
      result = d.filter((item) => item.local.includes(valor));
      
      for (let item of result) {
        template_brands += `
        <tr>
          <td>${item.id}</td>
          <td><img width="100px" src="${item.logo}"alt></td>
          <td>${item.name}</td>
          <td>${item.local}</td>
          <td>${item.floor}</td>
          <td>${item.schedule}</td>
          <td><a href="${item.website}" target="_blank">Sitio web</a></td>
          <td>
            <button class="btn btn-sm btn-info" type="button" class="btn btn-secondary"
            data-bs-toggle="modal" data-bs-target="#detail_brand" onclick="detailBrand('${item.id}')">Detalles</button>
            <button class="btn btn-sm btn-warning" type="button" class="btn btn-secondary"
            data-bs-toggle="modal" data-bs-target="#edit_brand" onclick="fill('${item.id}')">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="deleteBrand('${item.id}')">Eliminar</button>
          </td>
        </tr>
        `;
        tbody.innerHTML = template_brands;
      }
    });
}

/* función para buscar por piso */
function searchPiso() {
  let valor = document.getElementById("search_piso").value;
  fetch("http://localhost:3000/brands")
    .then((r) => r.json())
    .then((d) => {
      let template_brands = "";
      let tbody = document.getElementById("tbody");
      result = d.filter((item) => item.floor.includes(valor));
      
      for (let item of result) {
        template_brands += `
        <tr>
          <td>${item.id}</td>
          <td><img width="100px" src="${item.logo}"alt></td>
          <td>${item.name}</td>
          <td>${item.local}</td>
          <td>${item.floor}</td>
          <td>${item.schedule}</td>
          <td><a href="${item.website}" target="_blank">Sitio web</a></td>
          <td>
            <button class="btn btn-sm btn-info" type="button" class="btn btn-secondary"
            data-bs-toggle="modal" data-bs-target="#detail_brand" onclick="detailBrand('${item.id}')">Detalles</button>
            <button class="btn btn-sm btn-warning" type="button" class="btn btn-secondary"
            data-bs-toggle="modal" data-bs-target="#edit_brand" onclick="fill('${item.id}')">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="deleteBrand('${item.id}')">Eliminar</button>
          </td>
        </tr>
        `;
        tbody.innerHTML = template_brands;
      }
    });
}