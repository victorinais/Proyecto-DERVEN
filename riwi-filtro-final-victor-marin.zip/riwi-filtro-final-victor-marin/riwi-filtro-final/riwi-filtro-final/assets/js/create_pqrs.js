/* se obtienen los datos del localStorage para insertar nombre y mantener sesión abierta */
let nombre = localStorage.getItem("nombre");
let autenticacion = localStorage.getItem("autenticado");

/* se personaliza el nombre de pqrs */
document.getElementById("nombre").innerText = nombre;

/* guardian para no mantener sesion abierta */
if (autenticacion != "si") {
  location.href = "./../index.html";
}

/* petición para mostrar pqrs */
template_create_pqrs = "";
fetch("http://localhost:3000/pqrs")
  .then((r) => r.json())
  .then((d) => {
    let tbody = document.getElementById("tbody");
    d.forEach((item) => {
      template_create_pqrs += `
      <tr>
        <td>${item.id}</td>
        <td>${item.name}</td>
        <td>${item.email}</td>
        <td>${item.content}</td>
        <td>
          <button class="btn btn-sm btn-danger" onclick="deletePqrs('${item.id}')">Eliminar</button>
        </td>
      </tr>
      `;
      tbody.innerHTML = template_create_pqrs;
    });
  });

/* funcion para eliminar pqrs */
function deletePqrs(id) {
  fetch("http://localhost:3000/pqrs/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((r) => r.json())
    .then((d) => {
      location.href = "";
    });
}

/* funcion para cerrar sesión */
if (localStorage.getItem("autenticado") == "si") {
  let btn = document.getElementById("close");
  btn.addEventListener("click", close);
  function close() {
    localStorage.setItem("nombre", "");
    localStorage.setItem("autenticado", "");
    location.href = "./../index.html";
  }
}

/* función para buscar por tipo (: queda pendiente no logre hacerlo funcional */
function searchTipo() {
  let valor = document.getElementById("search_tipo");
  if (valor.value == 1){
    valor = "Petición";
  } else if(valor.value == 2){
    valor = "Queja";
  } else if(valor.value == 3){
    valor = "Reclamo";
  } else if (valor.value == 4) {
    valor = "Sugerencia";
  }
  
  fetch("http://localhost:3000/pqrs" + valor)
    .then(r => r.json())
    .then(d => {
      let template_pqrs = ""
      let tbody = document.getElementById("tbody");
      result = d.filter(item => item.name.includes(valor))

      for (let item of result) {
        template_pqrs += `
        <tr>
          <td>${item.id}</td>
          <td>${item.name}</td>
          <td>${item.email}</td>
          <td>${item.content}</td>
          <td>
            <button class="btn btn-sm btn-danger" onclick="deletePqrs('${item.id}')">Eliminar</button>
          </td>
        </tr>
        `
        tbody.innerHTML = template_pqrs
      }
    })
}

/* función para buscar por email */
function searchEmail() {
  let valor = document.getElementById("search_email").value.toLowerCase();
  fetch("http://localhost:3000/pqrs")
    .then(r => r.json())
    .then(d => {
      let template_pqrs = ""
      let tbody = document.getElementById("tbody");
      result = d.filter(item => item.email.toLowerCase().includes(valor))

      for (let item of result) {
        template_pqrs += `
        <tr>
          <td>${item.id}</td>
          <td>${item.name}</td>
          <td>${item.email}</td>
          <td>${item.content}</td>
          <td>
            <button class="btn btn-sm btn-danger" onclick="deletePqrs('${item.id}')">Eliminar</button>
          </td>
        </tr>
        `
        tbody.innerHTML = template_pqrs
      }
    })
}

/* función para buscar por mensaje */
function searchMensaje() {
  let valor = document.getElementById("search_mensaje").value.toLowerCase();
  fetch("http://localhost:3000/pqrs")
    .then(r => r.json())
    .then(d => {
      let template_pqrs = ""
      let tbody = document.getElementById("tbody");
      result = d.filter(item => item.content.toLowerCase().includes(valor))

      for (let item of result) {
        template_pqrs += `
        <tr>
          <td>${item.id}</td>
          <td>${item.name}</td>
          <td>${item.email}</td>
          <td>${item.content}</td>
          <td>
            <button class="btn btn-sm btn-danger" onclick="deletePqrs('${item.id}')">Eliminar</button>
          </td>
        </tr>
        `
        tbody.innerHTML = template_pqrs
      }
    })
}
