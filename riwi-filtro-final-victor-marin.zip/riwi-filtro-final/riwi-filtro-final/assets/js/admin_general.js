/* se obtienen los datos del localStorage para insertar nombre y mantener sesión abierta */
let nombre = localStorage.getItem("nombre")
let autenticacion = localStorage.getItem("autenticado")

/* document.getElementById("name").innerText = nombre */

if (autenticacion != "si") {
  location.href = "./../index.html"
}

/* funcion para cerrar sesión */
if (localStorage.getItem("autenticado") == "si") {
  let btn = document.getElementById("close")
  btn.addEventListener("click", close)
  function close() {
    localStorage.setItem("nombre", "")
    localStorage.setItem("autenticado", "")
    location.href = "./../index.html"
  }
}
