/* petición para mostrar administradores */
template_create_admins = ""
fetch("http://localhost:3000/admins")
  .then(r => r.json())
  .then(d => {
    let tbody = document.getElementById("tbody")
    d.forEach(item => {
      template_create_admins += `
      <tr>
        <td>${item.id}</td>
        <td>${item.names}</td>
        <td>${item.email}</td>
        <td>
          <button class="btn btn-sm btn-info" type="button" class="btn btn-secondary"
          data-bs-toggle="modal" data-bs-target="#admin_detail" onclick="detailAdmin('${item.id}')">Detalles</button>
          <button class="btn btn-sm btn-warning" type="button" class="btn btn-secondary"
          data-bs-toggle="modal" data-bs-target="#admin_edit" onclick="fill('${item.id}')">Editar</button>
          <button class="btn btn-sm btn-danger" onclick="deleteAdmin('${item.id}')">Eliminar</button>
        </td>
      </tr>
      `
      tbody.innerHTML = template_create_admins
    })
  })

/* funcion para crear administradores */
function createAdmin() {
  let name = document.getElementById("name_create")
  let email = document.getElementById("email_create")

  let data_admin = {
    names: name.value,
    email: email.value
  }

  fetch("http://localhost:3000/admins", {
    method: "POST",
    body: JSON.stringify(data_admin),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(r => r.json())
    .then(d => {
      location.href = ""
    })
}

/* funcion para eliminar administradores */
function deleteAdmin(id) {
  fetch("http://localhost:3000/admins/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(r => r.json())
    .then(d => {
      location.href = ""
    })
}

/* funcion para rellenar modal */
function fill(id){
  fetch("http://localhost:3000/admins/" + id)
  .then(r => r.json())
  .then(d => {
    document.getElementById("name_edit").value = d.names
    document.getElementById("email_edit").value = d.email
    document.getElementById("id_edit").value = d.id
  })
}

/* funcion para editar administrador */
function update(){
  let names = document.getElementById("name_edit")
  let email = document.getElementById("email_edit")
  let id = document.getElementById("id_edit")

  let data_admin = {
    names: names.value,
    email: email.value
  }

  fetch("http://localhost:3000/admins/" + id.value, {
    method: "PUT",
    body: JSON.stringify(data_admin),
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(r => r.json())
  .then(d => {
    location.href = ""
  })
}

/* funcion para mostrar detalles administrador */
let template_detail_admin = "";
function detailAdmin(id) {
  fetch("http://localhost:3000/admins/" + id)
    .then(r => r.json())
    .then(d => {
      let tbody = document.getElementById("tbody_detail");
      template_detail_admin = `
      <tr>
        <th>Id:</th>
        <td>${d.id}</td>
      </tr>
      <tr>
        <th>Nombres:</th>
        <td>${d.names}</td>
      </tr>
      <tr>
        <th>Email:</th>
        <td>${d.email}</td>
      </tr>
      `
      tbody.innerHTML = template_detail_admin;

    })
}

/* funcion para cerrar sesión */
if (localStorage.getItem("autenticado") == "si") {
  let btn = document.getElementById("close")
  btn.addEventListener("click", close)
  function close() {
    localStorage.setItem("nombre", "")
    localStorage.setItem("autenticado", "")
    location.href = "./../index.html"
  }
}