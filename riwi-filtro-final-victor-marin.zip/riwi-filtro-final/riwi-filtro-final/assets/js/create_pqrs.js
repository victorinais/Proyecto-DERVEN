/* se obtienen los datos del localStorage para insertar nombre y mantener sesión abierta */
let nombre = localStorage.getItem("nombre");
let autenticacion = localStorage.getItem("autenticado");

document.getElementById("nombre").innerText = nombre;
if (autenticacion != "si") {
  location.href = "./../index.html";
}

/* petición para mostrar pqrs */
template_create_pqrs = "";
fetch("http://localhost:3000/pqrs")
  .then((r) => r.json())
  .then((d) => {
    let tbody = document.getElementById("tbody");
    d.forEach((item) => {
      template_create_pqrs += `
      <tr>
        <td>${item.id}</td>
        <td>${item.name}</td>
        <td>${item.email}</td>
        <td>${item.content}</td>
        <td>
          <button class="btn btn-sm btn-danger" onclick="deletePqrs('${item.id}')">Eliminar</button>
        </td>
      </tr>
      `;
      tbody.innerHTML = template_create_pqrs;
    });
  });

/* funcion para eliminar brands */
function deletePqrs(id) {
  fetch("http://localhost:3000/pqrs/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((r) => r.json())
    .then((d) => {
      location.href = "";
    });
}

/* funcion para cerrar sesión */
if (localStorage.getItem("autenticado") == "si") {
  let btn = document.getElementById("close");
  btn.addEventListener("click", close);
  function close() {
    localStorage.setItem("nombre", "");
    localStorage.setItem("autenticado", "");
    location.href = "./../index.html";
  }
}
