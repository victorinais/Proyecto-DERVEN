/* template para mostrar las cartas con las marcas */
template_cards = ""
fetch("http://localhost:3000/brands")
  .then(r => r.json())
  .then(d => {
    let cards = document.getElementById("cards")
    d.forEach(item => {
      template_cards += `
      <div class="card col-12 col-md-3 mx-1 my-1 shadow" >
        <img src="${item.logo}" class="card-img-top w-100" alt="imagen-procesador">
          <div class="card-body">
          <h5 class="card-title">${item.name}</h5>
          <p class="card-text">${item.description}</p>
          <a href="#" class="btn btn-primary w-100">Detalles</a>
        </div>
      </div>
      `
      cards.innerHTML = template_cards
    })
  })

/* función para buscar brands */
fetch("http://localhost:3000/brands")
  .then(r => r.json())
  .then(d => {
    document.getElementById("search").addEventListener("keyup", () => {
      template_cards_brands = ""
      let valor = document.getElementById("search").value.toLowerCase();
      let results = d.filter(item => item.name.toLowerCase().includes(valor));
      let cards = document.getElementById("cards");

      for (let item of results) {
        template_cards_brands += `
        <div class="card col-12 col-md-3 mx-1 my-1 shadow" >
          <img src="${item.logo}" class="card-img-top w-100" alt="imagen-procesador">
            <div class="card-body">
            <h5 class="card-title">${item.name}</h5>
            <p class="card-text">${item.description}</p>
            <a href="#" class="btn btn-primary w-100">Detalles</a>
          </div>
        </div>
        `
        cards.innerHTML = template_cards_brands
      }
    })
  })