
/* funcion para verificar usuario */
function verifyUser() {
  let email = document.getElementById("email")
  let password = document.getElementById("password")

  fetch("http://localhost:3000/admins")
    .then(r => r.json())
    .then(d => {

      let result = d.filter(function (element) {
        if (element.email == email.value) {
          return element
        }
      })

      if (result.length > 0) {
          if (result[0].password == password.value) {
            localStorage.setItem("autenticado", "si")
            localStorage.setItem("nombre", result[0].names);
            location.href = "./admin/index.html"
          } else {
            console.log("correo y contraseña incorrecto")
          }
        } else {
          console.log("No hay coincidencias")
        }
    })
}
