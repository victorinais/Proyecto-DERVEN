/* funcion para crear pqrs */
function createPqrs() {
  let seleccion = document.getElementById("select_create")
  let email = document.getElementById("email_create")
  let content = document.getElementById("content")

  if (seleccion.value == 1){
    seleccion = "Petición";
  } else if(seleccion.value == 2){
    seleccion = "Queja";
  } else if(seleccion.value == 3){
    seleccion = "Reclamo";
  } else if (seleccion.value == 4) {
    seleccion = "Sugerencia";
  }

  let data_qrps = {
    name: seleccion,
    email: email.value,
    content: content.value
  }

  fetch("http://localhost:3000/pqrs", {
    method: "POST",
    body: JSON.stringify(data_qrps),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(r => r.json())
    .then(d => {
      location.href = ""
    }) 
}
